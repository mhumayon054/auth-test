"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import AuthCard from "@/components/AuthCard";
import { useSignUpMutation } from "@/store/api";

export default function SignUpPage() {
  const router = useRouter();
  const [signUp, { isLoading }] = useSignUpMutation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  return (
    <main className="min-h-screen bg-[#070A0F] px-4 py-14 items-center align-self-center flex">
      <div className="mx-auto flex max-w-6xl items-center justify-center">
        <AuthCard
          title="Create account"
          subtitle="Create your account to access the protected home page."
          footerText="Already have an account?"
          footerLinkText="Sign in"
          footerHref="/signin"
        >
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setError(null);
              try {
                await signUp({ email, password }).unwrap();
                router.push("/signin");
              } catch (err: any) {
                setError(err?.data?.message ?? "Signup failed");
              }
            }}
            className="space-y-4"
          >
            <div>
              <label className="mb-2 block text-xs text-white/70">Email</label>
              <input
                className="w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/30 focus:border-white/25"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
              />
            </div>

            <div>
              <label className="mb-2 block text-xs text-white/70">Password</label>
              <input
                type="password"
                className="w-full rounded-xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none placeholder:text-white/30 focus:border-white/25"
                placeholder="minimum 8 chars"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
              />
            </div>

            {error && (
              <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-200">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full rounded-xl bg-white px-4 py-3 text-sm font-medium text-black hover:bg-white/90 disabled:opacity-60"
            >
              {isLoading ? "Creating..." : "Create account"}
            </button>
          </form>
        </AuthCard>
      </div>
    </main>
  );
}