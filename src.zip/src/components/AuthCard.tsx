import Link from "next/link";

type Props = {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  footerText: string;
  footerLinkText: string;
  footerHref: string;
};

export default function AuthCard({
  title,
  subtitle,
  children,
  footerText,
  footerLinkText,
  footerHref,
}: Props) {
  return (
    <div className="w-full max-w-md rounded-2xl border border-white/10 bg-white/5 p-6 shadow-2xl backdrop-blur">
      <h1 className="text-2xl font-semibold tracking-tight text-white">{title}</h1>
      <p className="mt-2 text-sm text-white/60">{subtitle}</p>

      <div className="mt-6">{children}</div>

      <p className="mt-6 text-center text-sm text-white/60">
        {footerText}{" "}
        <Link href={footerHref} className="text-white hover:underline">
          {footerLinkText}
        </Link>
      </p>
    </div>
  );
}