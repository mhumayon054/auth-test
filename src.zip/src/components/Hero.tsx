"use client";

import Link from "next/link";
import { useSession } from "next-auth/react";

export default function Hero() {
  const { data: session } = useSession();

  const isLoggedIn = !!session;

  return (
    <section className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-white/5 blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-[calc(100vh-72px)] max-w-6xl flex-col items-center justify-center px-4 py-16 text-center">

        {isLoggedIn ? (
          <>
            <h1 className="max-w-3xl text-4xl font-semibold tracking-tight text-white sm:text-5xl md:text-6xl">
              Welcome back.
              <span className="text-white/70"> You're successfully authenticated.</span>
            </h1>

            <p className="mt-5 max-w-2xl text-base leading-relaxed text-white/60 sm:text-lg">
              You're in. Let's get started.
            </p>
          </>
        ) : (
          <>
            <h1 className="max-w-3xl text-4xl font-semibold tracking-tight text-white sm:text-5xl md:text-6xl">
              Clean authentication UI.
              <span className="text-white/70"> Built for a secure login flow.</span>
            </h1>

            <p className="mt-5 max-w-2xl text-base leading-relaxed text-white/60 sm:text-lg">
              Sign in, sign up, and a protected home route. Backend logic (NextAuth + lockout).
            </p>

            <div className="mt-8 flex gap-3 justify-center">
              <Link
                href="/signup"
                className="rounded-full bg-white px-6 py-3 text-sm font-medium text-black hover:bg-white/90"
              >
                Create account
              </Link>
              <Link
                href="/signin"
                className="rounded-full border border-white/15 bg-white/5 px-6 py-3 text-sm font-medium text-white hover:bg-white/10"
              >
                Sign in
              </Link>
            </div>
          </>
        )}
      </div>
    </section>
  );
}